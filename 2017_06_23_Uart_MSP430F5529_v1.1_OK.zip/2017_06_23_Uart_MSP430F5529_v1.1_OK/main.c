/*******************************************************************************
  * @File    : main.c
  * @Author  : Redouane Es-sadaoui <redouane.essadaoui@my-enova.com>, Arkeocean
  * @Brief   : UART API
  * @Tools   : IDE- Code composer studio v5.5, Target- MSP430F5529LP
  * @Date    : Last update, June 23, 2017
*******************************************************************************/
#include <msp430.h>
#define TXnotRX  0  //transmitter = 1, receiver = 0
#define loopBack

char myString[] =  {"hello I m Redouane"};
char *txData = myString;
char rxData[64];
char offsetTab = 0;

int main(void)
{
  WDTCTL = WDTPW | WDTHOLD;                 // Stop WDT

  P3SEL |= BIT3 | BIT4;                    // Assign P3.3 to UCA0TXD and...
  P3DIR |= BIT3;                           // P3.4 to UCA0RXD

  UCA0CTL1 |= UCSWRST;                      // **Put state machine in reset**

  UCA0CTL1 |= UCSSEL_1;                     // CLK = ACLK
  UCA0BR0 |= 0x03;                           // 0x0332kHz/9600=3.41 (see User's Guide)
  UCA0BR1 = 0x00;                           //
  UCA0MCTL = UCBRS_3|UCBRF_0;               // Modulation UCBRSx=3, UCBRFx=0

  UCA0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
  UCA0IE |= UCRXIE;                         // Enable USCI_A0 RX interrupt

  _enable_interrupt();

  while (1){


 UCA0TXBUF = 0xCA;


  }



}

// UART ISR
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)

{
  switch(__even_in_range(UCA0IV, 4))
  {
  case 0:break;                             // Vector 0 - no interrupt
  case 2:                                   // Vector 2 - RXIFG
    while (!(UCA0IFG & UCTXIFG));             // USCI_A0 TX buffer ready?
    rxData[offsetTab++] = UCA0RXBUF;
#ifdef loopBack
    // loop back
    UCA0TXBUF = UCA0RXBUF;                  // TX -> RXed character
#endif

    break;
  case 4:break;                             // Vector 4 - TXIFG
  default: break;
  }
}


